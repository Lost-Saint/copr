<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk" sourcelanguage="en_GB">
<context>
    <name>AppView</name>
    <message>
        <location filename="../gui/AppView.qml" line="143"/>
        <location filename="../gui/AppView.qml" line="299"/>
        <source>Resume Game</source>
        <translation>Відновити гру</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="169"/>
        <location filename="../gui/AppView.qml" line="303"/>
        <source>Quit Game</source>
        <translation>Вийти з гри</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="299"/>
        <source>Launch Game</source>
        <translation>Запустити гру</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="310"/>
        <source>Direct Launch</source>
        <translation>Прямий запуск</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="314"/>
        <source>Launch this app immediately when the host is selected, bypassing the app selection grid.</source>
        <translation>Запустити цю гру одразу ж як обраний хост, пропускаючи вибір гри.</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="322"/>
        <source>Hide Game</source>
        <translation>Сховати гру</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="326"/>
        <source>Hide this game from the app grid. To access hidden games, right-click on the host and choose %1.</source>
        <translation>Приховати цю гру в на екрані ігор. Щоб отримати доступ до прихованих ігор, клацніть правою кнопкою миші на хості та виберіть %1.</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="326"/>
        <source>View All Apps</source>
        <translation>Переглянути усі ігри</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="341"/>
        <source>This computer doesn&apos;t seem to have any applications or some applications are hidden</source>
        <translation>Схоже цей комп&apos;ютер не має ніяких додатків або деякі додатки приховані</translation>
    </message>
    <message>
        <location filename="../gui/AppView.qml" line="354"/>
        <source>Are you sure you want to quit %1? Any unsaved progress will be lost.</source>
        <translation>Ви впевнені, що хочете вийти з %1? Будь-який незбережений прогрес буде втрачено.</translation>
    </message>
</context>
<context>
    <name>CliPair</name>
    <message>
        <location filename="../gui/CliPair.qml" line="8"/>
        <source>Establishing connection to PC...</source>
        <translation>Під&apos;єднання до ПК...</translation>
    </message>
    <message>
        <location filename="../gui/CliPair.qml" line="12"/>
        <source>Pairing... Please enter &apos;%1&apos; on %2.</source>
        <translation>З&apos;єднання... Будь ласка, введіть &apos;%1&apos; на %2.</translation>
    </message>
    <message>
        <location filename="../gui/CliPair.qml" line="81"/>
        <source>Pairing completed successfully</source>
        <translation>З&apos;єднання успішно завершено</translation>
    </message>
</context>
<context>
    <name>CliQuitStreamSegue</name>
    <message>
        <location filename="../gui/CliQuitStreamSegue.qml" line="9"/>
        <source>Establishing connection to PC...</source>
        <translation>Під&apos;єднання до ПК...</translation>
    </message>
    <message>
        <location filename="../gui/CliQuitStreamSegue.qml" line="13"/>
        <source>Quitting app...</source>
        <translation>Вихід з гри...</translation>
    </message>
</context>
<context>
    <name>CliStartStreamSegue</name>
    <message>
        <location filename="../gui/CliStartStreamSegue.qml" line="8"/>
        <source>Establishing connection to PC...</source>
        <translation>Під&apos;єднання до ПК...</translation>
    </message>
    <message>
        <location filename="../gui/CliStartStreamSegue.qml" line="12"/>
        <source>Loading app list...</source>
        <translation>Завантаження списку ігор...</translation>
    </message>
    <message>
        <location filename="../gui/CliStartStreamSegue.qml" line="78"/>
        <source>Are you sure you want to quit %1? Any unsaved progress will be lost.</source>
        <translation>Ви впевнені, що хочете вийти з %1? Будь-який незбережений прогрес буде втрачено.</translation>
    </message>
</context>
<context>
    <name>ComputerModel</name>
    <message>
        <location filename="../gui/computermodel.cpp" line="50"/>
        <source>Online</source>
        <translation>У мережі</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="53"/>
        <source>Offline</source>
        <translation>Поза мережею</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="56"/>
        <location filename="../gui/computermodel.cpp" line="68"/>
        <location filename="../gui/computermodel.cpp" line="80"/>
        <location filename="../gui/computermodel.cpp" line="82"/>
        <location filename="../gui/computermodel.cpp" line="83"/>
        <source>Unknown</source>
        <translation>Невідомо</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="62"/>
        <source>Paired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="65"/>
        <source>Unpaired</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="72"/>
        <source>Name: %1</source>
        <translation>Назва: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="73"/>
        <source>Status: %1</source>
        <translation>Статус: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="74"/>
        <source>Active Address: %1</source>
        <translation>Активна адреса: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="75"/>
        <source>UUID: %1</source>
        <translation>UUID: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="76"/>
        <source>Local Address: %1</source>
        <translation>Локальна адреса: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="77"/>
        <source>Remote Address: %1</source>
        <translation>Віддалена адреса: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="78"/>
        <source>IPv6 Address: %1</source>
        <translation>Адреса IPv6: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="79"/>
        <source>Manual Address: %1</source>
        <translation>Уведена адреса: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="80"/>
        <source>MAC Address: %1</source>
        <translation>MAC-адреса: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="81"/>
        <source>Pair State: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="82"/>
        <source>Running Game ID: %1</source>
        <translation>Наразі у грі з ID: %1</translation>
    </message>
    <message>
        <location filename="../gui/computermodel.cpp" line="83"/>
        <source>HTTPS Port: %1</source>
        <translation>Порт HTTPS: %1</translation>
    </message>
</context>
<context>
    <name>GamepadMapper</name>
    <message>
        <location filename="../gui/GamepadMapper.qml" line="4"/>
        <source>Gamepad Mapping</source>
        <translation>Налаштування геймпада</translation>
    </message>
</context>
<context>
    <name>NvHTTP</name>
    <message>
        <location filename="../backend/nvhttp.cpp" line="381"/>
        <source>Missing audio capture device. Reinstalling GeForce Experience should resolve this error.</source>
        <translation>Відсутній пристрій запису звуку. Перевстановлення GeForce Experience має усунути цю помилку.</translation>
    </message>
</context>
<context>
    <name>PcView</name>
    <message>
        <location filename="../gui/PcView.qml" line="21"/>
        <source>Computers</source>
        <translation>Комп&apos;ютери</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="63"/>
        <source>Unable to connect to the specified PC.</source>
        <translation>Неможливо під&apos;єднатися до цього ПК.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="66"/>
        <source>This PC&apos;s Internet connection is blocking Moonlight. Streaming over the Internet may not work while connected to this network.</source>
        <translation>З&apos;єднання вашого ПК до інтернету, блокує Moonlight. Транслювання через інтернет може не працювати доки ви під&apos;єднані до цієї мережі.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="69"/>
        <source>Click the Help button for possible solutions.</source>
        <translation>Натисніть на кнопку Допомога для можливих рішень проблем.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="100"/>
        <source>Automatic PC discovery is disabled. Add your PC manually.</source>
        <translation>Автоматичне виявлення ПК вимкнено. Додайте свій ПК вручну.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="99"/>
        <source>Searching for compatible hosts on your local network...</source>
        <translation>Пошук сумісних хостів у локальній мережі...</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="184"/>
        <source>Wake PC</source>
        <translation>Розбудити ПК</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="189"/>
        <source>Test Network</source>
        <translation>Перевірити мережу</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="197"/>
        <source>Rename PC</source>
        <translation>Перейменувати ПК</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="205"/>
        <source>Delete PC</source>
        <translation>Видалити ПК</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="213"/>
        <source>View Details</source>
        <translation>Деталі</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="225"/>
        <source>The version of GeForce Experience on %1 is not supported by this build of Moonlight. You must update Moonlight to stream from %1.</source>
        <translation>Версія GeForce Experience на %1 не підтримується цією збіркою MoonLight. Потрібно оновити Moonlight, щоб транслювати з %1.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="324"/>
        <source>This may take a few seconds…</source>
        <translation>Це може зайняти кілька секунд…</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="335"/>
        <source>This network does not appear to be blocking Moonlight. If you still have trouble connecting, check your PC&apos;s firewall settings.</source>
        <translation>Схоже, ця мережа не блокує Moonlight. Якщо у вас все ще виникають проблеми з під&apos;єднанням, перевірте налаштування брандмауера вашого ПК.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="335"/>
        <source>If you are trying to stream over the Internet, install the Moonlight Internet Hosting Tool on your gaming PC and run the included Internet Streaming Tester to check your gaming PC&apos;s Internet connection.</source>
        <translation>Якщо ви намагаєтеся вести трансляцію через Інтернет, встановіть застосунок Moonlight Internet Hosting Tool на свій ігровий ПК та запустіть Internet Streaming Tester, щоб перевірити з&apos;єднання з інтернетом вашого ігрового ПК.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="339"/>
        <source>Your PC&apos;s current network connection seems to be blocking Moonlight. Streaming over the Internet may not work while connected to this network.</source>
        <translation>Схоже, поточна мережа вашого ПК блокує Moonlight. Трансляція через Інтернет може не працювати доки ви під&apos;єднані до цієї мережі.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="339"/>
        <source>The following network ports were blocked:</source>
        <translation>Заблоковані такі мережеві порти:</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="331"/>
        <source>The network test could not be performed because none of Moonlight&apos;s connection testing servers were reachable from this PC. Check your Internet connection or try again later.</source>
        <translation>Не вдалося виконати тест мережі, оскільки жоден із серверів тестування під&apos;єднання Moonlight не був знайдений з цього ПК. Перевірте під&apos;єднання до Інтернету або спробуйте пізніше.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="170"/>
        <source>PC Status: %1</source>
        <translation>Статус ПК: %1</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="170"/>
        <source>Online</source>
        <translation>У мережі</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="170"/>
        <source>Offline</source>
        <translation>Поза мережею</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="175"/>
        <source>View All Apps</source>
        <translation>Переглянути усі ігри</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="297"/>
        <source>Please enter %1 on your host PC. This dialog will close when pairing is completed.</source>
        <translation>Будь ласка, введіть %1 на хост-ПК. Це вікно закриється, коли з&apos;єднання буде завершено.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="298"/>
        <source>If your host PC is running Sunshine, navigate to the Sunshine web UI to enter the PIN.</source>
        <translation>Якщо Sunshine працює на вашому хост-ПК, відкрийте вебінтерфейс Sunshine, щоб ввести PIN-код.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="310"/>
        <source>Are you sure you want to remove &apos;%1&apos;?</source>
        <translation>Ви дійсно бажаєте видалити «%1»?</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="324"/>
        <source>Moonlight is testing your network connection to determine if any required ports are blocked.</source>
        <translation>Moonlight перевіряє мережу, щоб визначити, чи заблоковані потрібні порти.</translation>
    </message>
    <message>
        <location filename="../gui/PcView.qml" line="351"/>
        <source>Enter the new name for this PC:</source>
        <translation>Введіть нове ім&apos;я для цього ПК:</translation>
    </message>
</context>
<context>
    <name>PendingPairingTask</name>
    <message>
        <location filename="../backend/computermanager.cpp" line="604"/>
        <source>The PIN from the PC didn&apos;t match. Please try again.</source>
        <translation>ПІН-код від ПК не збігається. Спробуйте ще раз.</translation>
    </message>
    <message>
        <location filename="../backend/computermanager.cpp" line="608"/>
        <source>You cannot pair while a previous session is still running on the host PC. Quit any running games or reboot the host PC, then try pairing again.</source>
        <translation>Ви не можете створити пару, доки попередній сеанс не закінчено на хост-ПК. Вийдіть із запущених ігор або перезавантажте хост-ПК, а потім спробуйте створити пару знову.</translation>
    </message>
    <message>
        <location filename="../backend/computermanager.cpp" line="611"/>
        <source>Pairing failed. Please try again.</source>
        <translation>З&apos;єднання не вдалося. Спробуйте ще раз.</translation>
    </message>
    <message>
        <location filename="../backend/computermanager.cpp" line="615"/>
        <source>Another pairing attempt is already in progress.</source>
        <translation>Ще одна спроба з&apos;єднатися вже триває.</translation>
    </message>
    <message>
        <location filename="../backend/computermanager.cpp" line="625"/>
        <source>GeForce Experience returned error: %1</source>
        <translation>Помилка GeForce Experience: %1</translation>
    </message>
</context>
<context>
    <name>PendingQuitTask</name>
    <message>
        <location filename="../backend/computermanager.cpp" line="675"/>
        <source>The running game wasn&apos;t started by this PC. You must quit the game on the host PC manually or use the device that originally started the game.</source>
        <translation>Цю гру запустив не цей ПК. Ви повинні вийти з гри на хост-ПК вручну або використовувати пристрій, з якого була запущена гра.</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../cli/pair.cpp" line="80"/>
        <source>%1 is already paired</source>
        <translation>%1 вже з&apos;єднано</translation>
    </message>
    <message>
        <location filename="../cli/pair.cpp" line="109"/>
        <location filename="../cli/quitstream.cpp" line="76"/>
        <location filename="../cli/startstream.cpp" line="133"/>
        <source>Failed to connect to %1</source>
        <translation>Не вдалося під&apos;єднатися до %1</translation>
    </message>
    <message>
        <location filename="../cli/quitstream.cpp" line="88"/>
        <location filename="../cli/startstream.cpp" line="89"/>
        <source>Computer %1 has not been paired. Please open Moonlight to pair before streaming.</source>
        <translation>З ком&apos;ютером %1 не було створено пари. Будь ласка відкрийте Moonlight щоб створити пару перед тим як запускати трансляцію.</translation>
    </message>
    <message>
        <location filename="../cli/quitstream.cpp" line="102"/>
        <location filename="../cli/startstream.cpp" line="126"/>
        <source>Quitting app failed, reason: %1</source>
        <translation>Не вдалося вийти з гри, через: %1</translation>
    </message>
    <message>
        <location filename="../cli/startstream.cpp" line="137"/>
        <source>Failed to find application %1</source>
        <translation>Не вдалося знайти застосунок %1</translation>
    </message>
    <message>
        <location filename="../cli/listapps.cpp" line="108"/>
        <source>Computer %1 has not been paired. Please open Moonlight to pair before retrieving games list.</source>
        <translation>Комп&apos;ютер %1 не було з&apos;єднано. Будь ласка, запустіть Moonlight для з&apos;єднання перед тим, як отримати список ігор.</translation>
    </message>
</context>
<context>
    <name>QPlatformTheme</name>
    <message>
        <location filename="../main.cpp" line="867"/>
        <source>&amp;Yes</source>
        <translation>&amp;Так</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="868"/>
        <source>&amp;No</source>
        <translation>&amp;Ні</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="869"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="870"/>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <location filename="../main.cpp" line="871"/>
        <source>Cancel</source>
        <translation>Скасувати</translation>
    </message>
</context>
<context>
    <name>QuitSegue</name>
    <message>
        <location filename="../gui/QuitSegue.qml" line="13"/>
        <source>Quitting %1...</source>
        <translation>Виходимо з %1...</translation>
    </message>
</context>
<context>
    <name>Session</name>
    <message>
        <location filename="../streaming/session.cpp" line="104"/>
        <source>No video received from host.</source>
        <translation>Немає відео з хоста.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="105"/>
        <source>Check your firewall and port forwarding rules for port(s): %1</source>
        <translation>Перевірте ваш брандмауер та правила відкриття наступних портів: %1</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="110"/>
        <source>Your network connection isn&apos;t performing well. Reduce your video bitrate setting or try a faster connection.</source>
        <translation>Ваша мережа не справляється. Зменшіть бітрейт або спробуйте швидшу мережу.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="116"/>
        <source>Something went wrong on your host PC when starting the stream.</source>
        <translation>Щось пішло не так під час запуску трансляції на хост-ПК.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="117"/>
        <source>Make sure you don&apos;t have any DRM-protected content open on your host PC. You can also try restarting your host PC.</source>
        <translation>Переконайтеся, що на вашому хост-ПК не відкрито захищений DRM вміст. Ви також можете спробувати перезавантажити хост-ПК.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="131"/>
        <source>Connection terminated</source>
        <translation>З&apos;єднання розірване</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="958"/>
        <source>The version of GeForce Experience on %1 is not supported by this build of Moonlight. You must update Moonlight to stream from %1.</source>
        <translation>Версія GeForce Experience на %1 не підтримується цією збіркою Moonlight. Оновіть Moonlight для транслювання з %1.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="963"/>
        <source>Your selection to enable remote desktop mouse mode may cause problems in games.</source>
        <translation>Ваш вибір увімкнути режим миші &quot;віддалений робочий стіл&quot; може викликати проблеми в іграх.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="967"/>
        <source>Your settings selection to force software decoding may cause poor streaming performance.</source>
        <translation>Ваш вибір примусити програмне декодування може викликати погану продуктивність трансляції.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1003"/>
        <source>Your host PC doesn&apos;t support encoding HEVC.</source>
        <translation>Хост не підтримує кодування HEVC.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1021"/>
        <source>Using software decoding due to your selection to force HEVC without GPU support. This may cause poor streaming performance.</source>
        <translation>Використання програмного декодування через вибір HEVC, котрий не підтримується відеокартою. Якість трансляції може погіршитися.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="973"/>
        <source>Your host software or GPU doesn&apos;t support encoding AV1.</source>
        <translation>ПЗ або відеокарта вашого хоста не підтримує кодування AV1.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="991"/>
        <source>Using software decoding due to your selection to force AV1 without GPU support. This may cause poor streaming performance.</source>
        <translation>Використання програмного декодування через вибір AV1, що не підтримується відеокартою. Якість трансляції може погіршитися.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1068"/>
        <source>Your host PC doesn&apos;t support HDR streaming.</source>
        <translation>Хост не підтримує транслювання HDR.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1060"/>
        <source>HDR is not supported using the H.264 codec.</source>
        <translation>HDR не підтримується під час використання кодека H.264.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1083"/>
        <source>This PC&apos;s GPU doesn&apos;t support AV1 Main10 decoding for HDR streaming.</source>
        <translation>Графічна карта цього ПК не підтримує декодування AV1 Main10 для транслювання HDR.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1064"/>
        <source>This PC&apos;s GPU doesn&apos;t support 10-bit HEVC or AV1 decoding for HDR streaming.</source>
        <translation>Відеокарта цього ПК не підтримує декодування 10-bit HEVC або AV1 для транслювання HDR.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1116"/>
        <source>Your host PC and client PC don&apos;t support the same HDR video codecs.</source>
        <translation>Хост та клієнт не підтримують однакові кодеки для HDR відео.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1209"/>
        <source>Video resolutions over 4K are not supported by the H.264 codec.</source>
        <translation>Роздільність понад 4K не підтримується кодеком H.264.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1606"/>
        <source>Host returned error: %1</source>
        <translation>Хост повернув помилку: %1</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="122"/>
        <source>The host PC reported a fatal video encoding error.</source>
        <translation>Хост повідомив про фатальну помилку кодування.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="123"/>
        <source>Try disabling HDR mode, changing the streaming resolution, or changing your host PC&apos;s display resolution.</source>
        <translation>Спробуйте вимкнути HDR, змінити роздільну здатність трансляції або змінити роздільну здатність на хост-ПК.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="132"/>
        <source>Error code: %1</source>
        <translation>Код помилки: %1</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1040"/>
        <source>Using software decoding due to your selection to force H.264 without GPU support. This may cause poor streaming performance.</source>
        <translation>Використання програмного декодування через вибір H.264, що не підтримується відеокартою. Якість трансляції може погіршитися.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1050"/>
        <source>Your host PC and client PC don&apos;t support the same video codecs. This may cause poor streaming performance.</source>
        <translation>Хост-ПК та клієнтський ПК не підтримують однакові відео кодеки. Якість трансляції може погіршитися.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1053"/>
        <source>Your client GPU doesn&apos;t support H.264 decoding. This may cause poor streaming performance.</source>
        <translation>Відеокарта на клієнті не підтримує декодування H.264. Якість трансляції може погіршитися.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1089"/>
        <location filename="../streaming/session.cpp" line="1107"/>
        <source>Using software decoding due to your selection to force HDR without GPU support. This may cause poor streaming performance.</source>
        <translation>Використання програмного декодування через вибір HDR, що не підтримується відеокартою. Якість трансляції може погіршитися.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1101"/>
        <source>This PC&apos;s GPU doesn&apos;t support HEVC Main10 decoding for HDR streaming.</source>
        <translation>Відеокарта цього ПК не підтримує декодування HEVC Main10 для транслювання HDR.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1123"/>
        <source>Your host PC doesn&apos;t support YUV 4:4:4 streaming.</source>
        <translation>Хост не підтримує транслювання YUV 4:4:4.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1131"/>
        <source>Your host PC doesn&apos;t support YUV 4:4:4 streaming for selected video codec.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1146"/>
        <source>Using software decoding due to your selection to force YUV 4:4:4 without GPU support. This may cause poor streaming performance.</source>
        <translation>Використання програмного декодування через вибір YUV 4:4:4, що не підтримується відеокартою. Якість трансляції може погіршитися.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1152"/>
        <source>This PC&apos;s GPU doesn&apos;t support YUV 4:4:4 decoding for selected video codec.</source>
        <translation>Відеокарта цього ПК не підтримує декодування YUV 4:4:4 для вибраного кодека.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1161"/>
        <source>GeForce Experience 3.0 or higher is required for 4K streaming.</source>
        <translation>Потрібно GeForce Experience 3.0 або вище для транслювання 4K.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1176"/>
        <source>Your selected surround sound setting is not supported by the current audio device.</source>
        <translation>Обрані налаштування об&apos;ємного звуку не підтримуються поточним аудіо пристроєм.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1182"/>
        <source>Failed to open audio device. Audio will be unavailable during this session.</source>
        <translation>Не вдалося відкрити аудіо пристрій. Аудіо буде відсутнім протягом цієї сесії.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1187"/>
        <source>An attached gamepad has no mapping and won&apos;t be usable. Visit the Moonlight help to resolve this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1205"/>
        <source>Your host PC&apos;s GPU doesn&apos;t support streaming video resolutions over 4K.</source>
        <translation>Відеокарта вашого хост-ПК не підтримує транслювання відео з роздільністю більше за 4K.</translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1223"/>
        <source>Your selection to force hardware decoding cannot be satisfied due to missing hardware decoding support on this PC&apos;s GPU.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="1226"/>
        <source>Your codec selection and force hardware decoding setting are not compatible. This PC&apos;s GPU lacks support for decoding your chosen codec.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../streaming/session.cpp" line="2204"/>
        <source>Unable to initialize video decoder. Please check your streaming settings and try again.</source>
        <translation>Не вдалося ініціалізувати відео декодер. Перевірте налаштування трансляції та спробуйте знову.</translation>
    </message>
</context>
<context>
    <name>SettingsView</name>
    <message>
        <location filename="../gui/SettingsView.qml" line="13"/>
        <source>Settings</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="116"/>
        <source>Resolution and FPS</source>
        <translation>Роздільність та FPS</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="124"/>
        <source>Setting values too high for your PC or network connection may cause lag, stuttering, or errors.</source>
        <translation>Виставлення зависокого значення для вашого ПК або мережі може спричинити лаг, статери або інші помилки.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="106"/>
        <source>Basic Settings</source>
        <translation>Базові налаштування</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="250"/>
        <source>720p</source>
        <translation>720p</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="256"/>
        <source>1080p</source>
        <translation>1080p</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="262"/>
        <source>1440p</source>
        <translation>1440p</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="268"/>
        <source>4K</source>
        <translation>4K</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="375"/>
        <source>Custom resolutions are not officially supported by GeForce Experience, so it will not set your host display resolution. You will need to set it manually while in game.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="376"/>
        <source>Resolutions that are not supported by your client or host PC may cause streaming errors.</source>
        <translation>Роздільність, що не підтримується вашим клієнтом або хост-ПК може спричинити помилки трансляції.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="382"/>
        <source>Enter a custom resolution:</source>
        <translation>Уведіть користувацьку роздільну здатність:</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="604"/>
        <source>%1 FPS</source>
        <translation>%1 К/с</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="672"/>
        <source>Video bitrate:</source>
        <translation>Бітрейт відео:</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="680"/>
        <source>Lower the bitrate on slower connections. Raise the bitrate to increase image quality.</source>
        <translation>Зменште бітрейт при повільному з&apos;єднанні. Підвищте бітрейт, щоб збільшити якість зображення.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="702"/>
        <source>Video bitrate: %1 Mbps</source>
        <translation>Бітрейт відео: %1 Мбіт/с</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="732"/>
        <source>Display mode</source>
        <translation>Режим показу</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="743"/>
        <location filename="../gui/SettingsView.qml" line="1218"/>
        <source>Fullscreen</source>
        <translation>Повноекранний</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="812"/>
        <source>Fullscreen generally provides the best performance, but borderless windowed may work better with features like macOS Spaces, Alt+Tab, screenshot tools, on-screen overlays, etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="748"/>
        <source>Borderless windowed</source>
        <translation>Безрамкове вікно</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="182"/>
        <source>Native</source>
        <translation>Нативний</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="183"/>
        <source>Native (Excluding Notch)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="718"/>
        <source>Use Default (%1 Mbps)</source>
        <translation>Стандартний (%1 Мбіт/с)</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="753"/>
        <location filename="../gui/SettingsView.qml" line="1210"/>
        <source>Windowed</source>
        <translation>Віконний</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="762"/>
        <source>(Recommended)</source>
        <translation>(Рекомендовано)</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="819"/>
        <source>V-Sync</source>
        <translation>Вертикальна синхронізація</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="829"/>
        <source>Disabling V-Sync allows sub-frame rendering latency, but it can display visible tearing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="836"/>
        <source>Frame pacing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="846"/>
        <source>Frame pacing reduces micro-stutter by delaying frames that come in too early</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="856"/>
        <source>Audio Settings</source>
        <translation>Налаштування аудіо</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="891"/>
        <source>Stereo</source>
        <translation>Стерео</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="895"/>
        <source>5.1 surround sound</source>
        <translation>Об&apos;ємний звук 5.1</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="899"/>
        <source>7.1 surround sound</source>
        <translation>Об&apos;ємний звук 7.1</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="913"/>
        <source>Mute host PC speakers while streaming</source>
        <translation>Заглушити динаміки на хост-ПК під час трансляції</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="923"/>
        <source>You must restart any game currently in progress for this setting to take effect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="929"/>
        <source>Mute audio stream when Moonlight is not the active window</source>
        <translation>Заглушити аудіо, коли Moonlight не фокусовано</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="940"/>
        <source>Mutes Moonlight&apos;s audio when you Alt+Tab out of the stream or click on a different window.</source>
        <translation>Заглушує аудіо від Moonlight, коли ви робите Alt+Tab з трансляції, або клацаєте на інше вікно.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="989"/>
        <source>UI Settings</source>
        <translation>Налаштування інтерфейсу</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="999"/>
        <source>Language</source>
        <translation>Мова</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1025"/>
        <source>Automatic</source>
        <translation>Автоматично</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1160"/>
        <source>You must restart Moonlight for this change to take effect</source>
        <translation>Потрібно перезапустити Moonlight для застосування</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1177"/>
        <source>GUI display mode</source>
        <translation>Режим показу інтерфейсу</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1214"/>
        <source>Maximized</source>
        <translation>Максимізований</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1242"/>
        <source>Show configuration warnings</source>
        <translation>Попередження конфігурації</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1298"/>
        <source>Input Settings</source>
        <translation>Налаштування уведення</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1319"/>
        <source>This enables seamless mouse control without capturing the client&apos;s mouse cursor. It is ideal for remote desktop usage but will not work in most games.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1321"/>
        <source>NOTE: Due to a bug in GeForce Experience, this option may not work properly if your host PC has multiple monitors.</source>
        <translation>ПРИМІТКА: Через помилку у GeForce Experience, ця опція може працювати не правильно, якщо у хост-ПК є кілька моніторів.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1621"/>
        <source>AV1</source>
        <translation>AV1</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1636"/>
        <source>Enable HDR</source>
        <translation>Увімкнути HDR</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1651"/>
        <source>The stream will be HDR-capable, but some games may require an HDR monitor on your host PC to enable HDR mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1653"/>
        <source>HDR streaming is not supported on this PC.</source>
        <translation>Транслювання HDR не підтримується на цьому ПК.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1659"/>
        <source>Enable YUV 4:4:4</source>
        <translation>Увімкнути YUV 4:4:4</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1740"/>
        <source>Show performance stats while streaming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1750"/>
        <source>Display real-time stream performance information while streaming.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1751"/>
        <source>You can toggle it at any time while streaming using Ctrl+Alt+Shift+S or Select+L1+R1+X.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1752"/>
        <source>The performance overlay is not supported on Steam Link or Raspberry Pi.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1340"/>
        <source>NOTE: Certain keyboard shortcuts like Ctrl+Alt+Del on Windows cannot be intercepted by any application, including Moonlight.</source>
        <translation>ПРИМІТКА: Деякі клавіатурні скорочення, як от Ctrl+Alt+Del на Windows, не можуть перехоплюватися будь-якими програмами, включно з Moonlight.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1403"/>
        <source>Use touchscreen as a virtual trackpad</source>
        <translation>Використовувати сенсорний екран як віртуальний трекпад</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1420"/>
        <source>Swap left and right mouse buttons</source>
        <translation>Поміняти ліву та праву кнопку миші місцями</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1432"/>
        <source>Reverse mouse scrolling direction</source>
        <translation>Інвертувати напрямок гортання</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1446"/>
        <source>Gamepad Settings</source>
        <translation>Налаштування геймпада</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1456"/>
        <source>Swap A/B and X/Y gamepad buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1466"/>
        <source>This switches gamepads into a Nintendo-style button layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1472"/>
        <source>Force gamepad #1 always connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1482"/>
        <source>Forces a single gamepad to always stay connected to the host, even if no gamepads are actually connected to this PC.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1320"/>
        <source>You can toggle this while streaming using Ctrl+Alt+Shift+M.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1490"/>
        <source>Enable mouse control with gamepads by holding the &apos;Start&apos; button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1501"/>
        <source>Process gamepad input when Moonlight is in the background</source>
        <translation>Перехоплювати уведення з контролера у фоні</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1512"/>
        <source>Allows Moonlight to capture gamepad inputs even if it&apos;s not the current window in focus</source>
        <translation>Дозволити Moonlight перехоплювати уведення з геймпада навіть якщо фокусоване інше вікно</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="949"/>
        <source>Host Settings</source>
        <translation>Налаштування хоста</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1521"/>
        <source>Advanced Settings</source>
        <translation>Просунуті налаштування</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="866"/>
        <source>Audio configuration</source>
        <translation>Конфігурація аудіо</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1231"/>
        <source>Show connection quality warnings</source>
        <translation>Попередження про якість з&apos;єднання</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1254"/>
        <source>Discord Rich Presence integration</source>
        <translation>Інтеграція Discord Rich Presence</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1264"/>
        <source>Updates your Discord status to display the name of the game you&apos;re streaming.</source>
        <translation>Показує у вашому статусі у Discord назву гри яку ви транслюєте.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1483"/>
        <source>Only enable this option when streaming a game that doesn&apos;t support gamepads being connected after startup.</source>
        <translation>Вмикайте цю опцію тільки коли транслюєте гру, котра не підтримує під&apos;єднання геймпада опісля запуску.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1309"/>
        <source>Optimize mouse for remote desktop instead of games</source>
        <translation>Оптимізувати мишу для віддаленого робочого стола замість ігор</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="512"/>
        <location filename="../gui/SettingsView.qml" line="622"/>
        <source>Custom (%1 FPS)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="527"/>
        <source>Enter a custom frame rate:</source>
        <translation>Користувацька частота оновлення:</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="219"/>
        <location filename="../gui/SettingsView.qml" line="228"/>
        <location filename="../gui/SettingsView.qml" line="625"/>
        <source>Custom</source>
        <translation>Користувацька</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="643"/>
        <source>30 FPS</source>
        <translation>30 К/с</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="648"/>
        <source>60 FPS</source>
        <translation>60 К/с</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1270"/>
        <source>Keep the display awake while streaming</source>
        <translation>Тримати монітор увімкненим під час трансляції</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1280"/>
        <source>Prevents the screensaver from starting or the display from going to sleep while streaming.</source>
        <translation>Запобігає запуску екранної заставки або переходу дисплея у режим сну під час трансляції.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1331"/>
        <source>Capture system keyboard shortcuts</source>
        <translation>Перехоплювати системні клавіатурні скорочення</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1339"/>
        <source>This enables the capture of system-wide keyboard shortcuts like Alt+Tab that would normally be handled by the client OS while streaming.</source>
        <translation>Вмикає перехоплення клавіатурних скорочень по типу Alt+Tab, котрі зазвичай обробляються операційною системою клієнта під час трансляції.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1369"/>
        <source>in fullscreen</source>
        <translation>коли на весь екран</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1373"/>
        <source>always</source>
        <translation>завжди</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1413"/>
        <source>When checked, the touchscreen acts like a trackpad. When unchecked, the touchscreen will directly control the mouse pointer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="959"/>
        <source>Optimize game settings for streaming</source>
        <translation>Оптимізувати налаштування гри для трансляції</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="970"/>
        <source>Quit app on host PC after ending stream</source>
        <translation>Вийти з програми на віддаленому ПК після завершення трансляції</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="980"/>
        <source>This will close the app or game you are streaming when you end your stream. You will lose any unsaved progress!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1531"/>
        <source>Video decoder</source>
        <translation>Відео декодер</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1556"/>
        <location filename="../gui/SettingsView.qml" line="1609"/>
        <source>Automatic (Recommended)</source>
        <translation>Автоматично (Рекомендовано)</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1560"/>
        <source>Force software decoding</source>
        <translation>Програмне декодування</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1564"/>
        <source>Force hardware decoding</source>
        <translation>Апаратне декодування</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1579"/>
        <source>Video codec</source>
        <translation>Відео кодек</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1613"/>
        <source>H.264</source>
        <translation>H.264</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1617"/>
        <source>HEVC (H.265)</source>
        <translation>HEVC (H.265)</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1681"/>
        <source>Good for streaming desktop and text-heavy games, but not recommended for fast-paced games.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1683"/>
        <source>YUV 4:4:4 is not supported on this PC.</source>
        <translation>YUV 4:4:4 не підтримується на цьому ПК.</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1689"/>
        <source>Unlock bitrate limit (Experimental)</source>
        <translation>Розблокувати ліміт бітрейту (Експериментально)</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1702"/>
        <source>This unlocks extremely high video bitrates for use with Sunshine hosts. It should only be used when streaming over an Ethernet LAN connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1708"/>
        <source>Automatically find PCs on the local network (Recommended)</source>
        <translation>Автоматично знаходити ПК на локальній мережі (Рекомендовано)</translation>
    </message>
    <message>
        <location filename="../gui/SettingsView.qml" line="1729"/>
        <source>Automatically detect blocked connections (Recommended)</source>
        <translation>Автоматично виявляти заблоковане з&apos;єднання (Рекомендовано)</translation>
    </message>
</context>
<context>
    <name>StreamSegue</name>
    <message>
        <location filename="../gui/StreamSegue.qml" line="12"/>
        <source>Resuming %1...</source>
        <translation>Відновлення %1...</translation>
    </message>
    <message>
        <location filename="../gui/StreamSegue.qml" line="13"/>
        <location filename="../gui/StreamSegue.qml" line="20"/>
        <source>Starting %1...</source>
        <translation>Запуск %1...</translation>
    </message>
    <message>
        <location filename="../gui/StreamSegue.qml" line="26"/>
        <source>Starting %1 failed: Error %2</source>
        <translation>Не вдалося запустити %1: Помилка %2</translation>
    </message>
    <message>
        <location filename="../gui/StreamSegue.qml" line="29"/>
        <source>Check your firewall and port forwarding rules for port(s): %1</source>
        <translation>Перевірте ваш брандмауер та правила переадресації для наступних портів: %1</translation>
    </message>
    <message>
        <location filename="../gui/StreamSegue.qml" line="65"/>
        <source>This PC&apos;s Internet connection is blocking Moonlight. Streaming over the Internet may not work while connected to this network.</source>
        <translation>Moonlight блокується підключенням до Інтернету цього ПК. Потокова трансляція через Інтернет може не працювати під час підключення до цієї мережі.</translation>
    </message>
    <message>
        <location filename="../gui/StreamSegue.qml" line="168"/>
        <source>Tip:</source>
        <translation>Підказка:</translation>
    </message>
    <message>
        <location filename="../gui/StreamSegue.qml" line="168"/>
        <source>Press %1 to disconnect your session</source>
        <translation>Натисніть %1, щоб вийти з сесії</translation>
    </message>
    <message>
        <location filename="../gui/StreamSegue.qml" line="169"/>
        <source>Start+Select+L1+R1</source>
        <translation>Start+Select+L1+R1</translation>
    </message>
    <message>
        <location filename="../gui/StreamSegue.qml" line="169"/>
        <source>Ctrl+Alt+Shift+Q</source>
        <translation>Ctrl+Alt+Shift+Q</translation>
    </message>
</context>
<context>
    <name>main</name>
    <message>
        <location filename="../gui/main.qml" line="444"/>
        <source>Settings</source>
        <translation>Налаштування</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="291"/>
        <source>Version %1</source>
        <translation>Версія %1</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="307"/>
        <source>Join our community on Discord</source>
        <translation>Доєднуйтеся до нашої спільноти у Discord</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="326"/>
        <source>Add PC manually</source>
        <translation>Додати ПК вручну</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="366"/>
        <source>Update available for Moonlight: Version %1</source>
        <translation>Доступна новіша версія Moonlight: %1</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="413"/>
        <source>Gamepad Mapper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="459"/>
        <source>Hardware acceleration doesn&apos;t work on XWayland. Continuing on XWayland may result in poor streaming performance. Try running with QT_QPA_PLATFORM=wayland or switch to X11.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="468"/>
        <source>This version of Moonlight isn&apos;t optimized for your PC. Please download the &apos;%1&apos; version of Moonlight for the best streaming performance.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="477"/>
        <source>Moonlight detected gamepads without a mapping:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="517"/>
        <source>Enter the IP address of your host PC:</source>
        <translation>Уведіть IP адресу вашого віддаленого ПК:</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="390"/>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="451"/>
        <source>No functioning hardware accelerated video decoder was detected by Moonlight. Your streaming performance may be severely degraded in this configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="453"/>
        <source>Click the Help button for more information on solving this problem.</source>
        <translation>Натисніть «Довідка», щоб отримати інформацію про розв&apos;язання проблеми.</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="461"/>
        <source>Click the Help button for more information.</source>
        <translation>Натисніть «Довідка» для детальнішої інформації.</translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="479"/>
        <source>Click the Help button for information on how to map your gamepads.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../gui/main.qml" line="487"/>
        <source>Are you sure you want to quit?</source>
        <translation>Ви впевнені, що хочете вийти?</translation>
    </message>
</context>
</TS>
